Now you can see that different folder have been cloned on your system, go to any folder and follow instruction from README file inside each folder
cd landing-page-httpd OR cd nlanding-page-nginx